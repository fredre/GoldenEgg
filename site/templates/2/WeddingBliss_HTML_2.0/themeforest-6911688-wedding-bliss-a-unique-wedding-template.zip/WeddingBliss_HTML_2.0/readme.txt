Wedding Bliss HTML template - version 1.0.0 - created on 18th of February 2014. For the documentation and more info on how to install and modify the template please see the folder "HELP"
------------------------
CURRENT VERSION: 2.0 - created on 12 May 2014

Updates:
- fixed IE9 compatibility
- guest book working php form
- update from jQuery 1.10 to 1.11
- google maps fix
- waypoint scroll fix

------------------------
Planned updates for version 3.0
- Preloader screen fix
- 10 pre-defined colors and backgrounds