# History

### 0.2.0, 25.05.2015

* Use attribute instead of element
* fix #7 (data-multiple don't working)
* fix #8 ($parse undefined error)
